export const promptSuggestions = [
  "A serene Japanese garden with cherry blossoms and a small bridge over a koi pond",
  "A futuristic cityscape with flying cars and neon lights at night",
  "A cozy cabin in a snowy forest with smoke coming from the chimney",
  "An underwater scene of a vibrant coral reef with tropical fish",
  "A fantasy castle on a floating island among clouds",
  "A steampunk airship flying through mountains at sunset",
  "A detailed close-up of a colorful chameleon on a branch",
  "A astronaut riding a horse on Mars",
  "A mystical forest with glowing mushrooms and fairy lights",
  "A robot chef preparing a gourmet meal in a modern kitchen"
];